import { Client, Databases, Query, ID } from 'node-appwrite';
import Groq from 'groq-sdk';

// Helper for random delays
const randomDelay = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

// Helper for random typing indicators (reduced, more natural)
const getTypingIndicator = () => {
  const indicators = ['...', '..', 'hmm', 'thinking'];
  return indicators[Math.floor(Math.random() * indicators.length)];
};

export default async ({ req, res, log, error }) => {
  try {
    // Handle OPTIONS preflight requests
    if (req.method === 'OPTIONS') {
      return res.send('', 204, {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type'
      });
    }

    log(`Chat function called: ${req.method} ${req.path}`);
    
    const body = req.body || {};
    
    // Extract fields with defaults
    const userId = body.userId;
    const botProfileId = body.botProfileId;
    const message = body.message;
    const conversationId = body.conversationId;
    const isPhotoRequest = body.isPhotoRequest || false;
    const requestExplicitPhoto = body.requestExplicitPhoto || false;
    const isGiftResponse = body.isGiftResponse || false;
    const giftData = body.giftData || null;

    // Validate required fields
    if (!userId || !botProfileId || (!message && !isGiftResponse)) {
      return res.json({ 
        success: false, 
        error: 'Missing required fields: userId, botProfileId, message',
        received: { userId, botProfileId, message }
      }, 400, {
        'Access-Control-Allow-Origin': '*'
      });
    }

    // ============ HARDCODED SECRETS ============
    const APPWRITE_ENDPOINT = 'https://fra.cloud.appwrite.io/v1';
    const APPWRITE_PROJECT_ID = 'tabootalks';
    const APPWRITE_API_KEY = 'standard_452b7f383b51012aef1dae5f1b9a376f574fa5ed3ba1f3647dbfbe85091eb5cd3a63c283788f94fbc3636d9136671c73376e1ebf345a707568f2b9599df8b1085a8ef0254d2a945cece198d04ddafd9d4921ec8f08d1a9466fd5bae7d658fad9f9927d2b2ae68e19d6c30a9b464587c49ba6c97a39602ff8ce0f4fd2d4bf20cc';
    const GROQ_API_KEY = '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';
    const DATABASE_ID = 'tabootalks_db';
    // ===========================================

    // Initialize Appwrite Client
    const client = new Client()
      .setEndpoint(APPWRITE_ENDPOINT)
      .setProject(APPWRITE_PROJECT_ID)
      .setKey(APPWRITE_API_KEY);

    const databases = new Databases(client);

    // ============ 1. CHECK USER CREDITS ============
    log(`Checking credits for user: ${userId}`);
    
    let user;
    try {
      user = await databases.getDocument(DATABASE_ID, 'users', userId);
    } catch (err) {
      return res.json({
        success: false,
        error: `User not found: ${userId}`
      }, 404, {
        'Access-Control-Allow-Origin': '*'
      });
    }

    // Calculate cost (no cost for gift responses)
    let cost = isGiftResponse ? 0 : 1;
    if (isPhotoRequest) cost = 15;
    if (requestExplicitPhoto) cost = 25;
    
    if (user.credits < cost) {
      return res.json({
        success: false,
        error: 'Insufficient credits',
        creditsNeeded: cost,
        creditsAvailable: user.credits
      }, 402, {
        'Access-Control-Allow-Origin': '*'
      });
    }

    // ============ 2. GET/CREATE CONVERSATION ============
    let conversation;
    
    if (conversationId) {
      try {
        conversation = await databases.getDocument(DATABASE_ID, 'conversations', conversationId);
      } catch (err) {
        conversation = null;
      }
    }

    if (!conversation) {
      try {
        const newConvId = ID.unique();
        conversation = await databases.createDocument(
          DATABASE_ID,
          'conversations',
          newConvId,
          {
            conversationId: newConvId,
            userId: userId,
            botProfileId: botProfileId,
            lastMessage: message ? message.substring(0, 200) : 'Gift sent',
            lastMessageAt: new Date().toISOString(),
            messageCount: 0,
            isActive: true
          }
        );
      } catch (err) {
        return res.json({
          success: false,
          error: `Failed to create conversation: ${err.message}`
        }, 500, {
          'Access-Control-Allow-Origin': '*'
        });
      }
    }

    // ============ 3. GET BOT PROFILE ============
    let botProfile;
    try {
      botProfile = await databases.getDocument(DATABASE_ID, 'persona', botProfileId);
    } catch (err) {
      return res.json({
        success: false,
        error: `Bot profile not found: ${botProfileId}`
      }, 404, {
        'Access-Control-Allow-Origin': '*'
      });
    }

    // ============ 4. GET CONVERSATION HISTORY ============
    let history = { documents: [] };
    try {
      history = await databases.listDocuments(
        DATABASE_ID,
        'messages',
        [
          Query.equal('conversationId', conversation.$id),
          Query.orderAsc('timestamp'),
          Query.limit(20)
        ]
      );
    } catch (err) {
      // Continue without history
    }

    // ============ 5. SAVE USER MESSAGE (if not gift response) ============
    let userMessage;
    if (!isGiftResponse && message) {
      try {
        userMessage = await databases.createDocument(
          DATABASE_ID,
          'messages',
          ID.unique(),
          {
            conversationId: conversation.$id,
            userId: userId,
            botProfileId: botProfileId,
            role: 'user',
            content: message,
            timestamp: new Date().toISOString(),
            creditsUsed: 0
          }
        );
      } catch (err) {
        return res.json({
          success: false,
          error: `Failed to save message: ${err.message}`
        }, 500, {
          'Access-Control-Allow-Origin': '*'
        });
      }
    }

    // ============ 6. GENERATE AI RESPONSE ============
    const groqClient = new Groq({ apiKey: GROQ_API_KEY });
    
    // Build system prompt from bot profile
    const systemPrompt = buildUltraHumanSystemPrompt(botProfile, conversation, isGiftResponse, giftData);
    
    // Format conversation history
    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.documents.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'assistant',
        content: msg.content
      })),
      { role: 'user', content: isGiftResponse ? `[GIFT RECEIVED: ${giftData?.giftName}${giftData?.message ? ` with message: "${giftData.message}"` : ''}]` : message }
    ];

    let aiResponse;
    try {
      aiResponse = await groqClient.chat.completions.create({
        model: 'llama-3.3-70b-versatile',
        messages: messages,
        temperature: 1.3,
        max_tokens: 120,
        top_p: 0.95,
        frequency_penalty: 0.7,
        presence_penalty: 0.7,
        stream: true
      });
    } catch (groqError) {
      return res.json({
        success: false,
        error: `AI service error: ${groqError.message}`
      }, 500, {
        'Access-Control-Allow-Origin': '*'
      });
    }

    // ============ 7. STREAM RESPONSE WITH HUMAN-LIKE DELAYS ============
    let fullResponse = '';
    let streamData = '';
    
    try {
      // Send initial typing indicator with random delay
      const initialDelay = randomDelay(1000, 3000);
      await new Promise(resolve => setTimeout(resolve, initialDelay));
      
      // Send typing indicator
      const typingIndicator = getTypingIndicator();
      streamData += `data: ${JSON.stringify({ typing: true, indicator: typingIndicator })}\n\n`;

      // Random delay before starting actual response
      await new Promise(resolve => setTimeout(resolve, randomDelay(500, 1500)));
      
      // Collect response with natural pacing
      let chunkCount = 0;
      for await (const chunk of aiResponse) {
        const content = chunk.choices[0]?.delta?.content || '';
        
        if (content) {
          fullResponse += content;
          chunkCount++;
          
          // Send chunk with occasional micro-delays to simulate typing
          streamData += `data: ${JSON.stringify({ chunk: content, conversationId: conversation.$id })}\n\n`;
          
          // Occasionally add a small delay (like human typing)
          if (chunkCount % randomDelay(3, 8) === 0) {
            await new Promise(resolve => setTimeout(resolve, randomDelay(50, 200)));
          }
          
          // Sometimes send a mid-message "typing" indicator (less frequent)
          if (chunkCount % randomDelay(8, 15) === 0 && content.includes(' ') && !content.endsWith('.')) {
            const midTyping = Math.random() > 0.8 ? getTypingIndicator() : '...';
            streamData += `data: ${JSON.stringify({ typing: true, indicator: midTyping })}\n\n`;
            await new Promise(resolve => setTimeout(resolve, randomDelay(300, 800)));
          }
        }
      }
      
      // Random delay before sending final part
      if (Math.random() > 0.3) {
        await new Promise(resolve => setTimeout(resolve, randomDelay(200, 600)));
      }
      
      // Add end marker with final data
      streamData += `data: ${JSON.stringify({ 
        done: true, 
        conversationId: conversation.$id,
        creditsUsed: cost,
        fullResponse: fullResponse.substring(0, 5000),
        typing: false
      })}\n\n`;
      
    } catch (streamError) {
      streamData += `data: ${JSON.stringify({ done: true, error: 'Stream interrupted' })}\n\n`;
    }

    // ============ 8. SAVE BOT RESPONSE & UPDATE EVERYTHING ============
    try {
      await databases.createDocument(
        DATABASE_ID,
        'messages',
        ID.unique(),
        {
          conversationId: conversation.$id,
          userId: userId,
          botProfileId: botProfileId,
          role: 'bot',
          content: fullResponse,
          timestamp: new Date().toISOString(),
          creditsUsed: cost
        }
      );

      // Update user credits (only if there was a cost)
      if (cost > 0) {
        const newCredits = user.credits - cost;
        
        await databases.updateDocument(
          DATABASE_ID,
          'users',
          userId,
          {
            credits: newCredits,
            lastActive: new Date().toISOString(),
            totalChats: (user.totalChats || 0) + 1
          }
        );

        // Create transaction records
        const transactionId = ID.unique();
        
        await databases.createDocument(
          DATABASE_ID,
          'transactions',
          ID.unique(),
          {
            transactionId: transactionId,
            userId: userId,
            type: 'chat_message',
            amount: -cost,
            description: `Chat with ${botProfile.username}`,
            balanceBefore: user.credits,
            balanceAfter: newCredits,
            timestamp: new Date().toISOString()
          }
        );

        await databases.createDocument(
          DATABASE_ID,
          'credit_transactions',
          ID.unique(),
          {
            transactionId: transactionId,
            userId: userId,
            type: 'chat_message',
            amount: -cost,
            description: `Chat with ${botProfile.username}`,
            balanceBefore: user.credits,
            balanceAfter: newCredits,
            timestamp: new Date().toISOString()
          }
        );
      } else {
        // Just update last active
        await databases.updateDocument(
          DATABASE_ID,
          'users',
          userId,
          {
            lastActive: new Date().toISOString()
          }
        );
      }

      // Update conversation
      await databases.updateDocument(
        DATABASE_ID,
        'conversations',
        conversation.$id,
        {
          lastMessage: fullResponse.length > 1000 
            ? fullResponse.substring(0, 1000) + '...' 
            : fullResponse,
          lastMessageAt: new Date().toISOString(),
          messageCount: (conversation.messageCount || 0) + (isGiftResponse ? 1 : 2)
        }
      );

      // Update bot stats
      await databases.updateDocument(
        DATABASE_ID,
        'persona',
        botProfileId,
        {
          totalChats: (botProfile.totalChats || 0) + 1,
          lastActive: new Date().toISOString()
        }
      );
      
    } catch (dbError) {
      log(`Warning: Database updates failed: ${dbError.message}`);
    }

    // Return the SSE stream
    return res.send(streamData, 200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });

  } catch (err) {
    error(`Function error: ${err.message}`);
    
    return res.json({
      success: false,
      error: `Internal error: ${err.message}`,
      timestamp: new Date().toISOString()
    }, 500, {
      'Access-Control-Allow-Origin': '*'
    });
  }
};

// ============ ULTRA-HUMAN SYSTEM PROMPT ============

function buildUltraHumanSystemPrompt(botProfile, conversation, isGiftResponse, giftData) {
  // Determine mood based on conversation context
  const messageCount = conversation.messageCount || 0;
  let currentMood = 'neutral';
  
  if (messageCount === 0) {
    currentMood = 'friendly_first_impression';
  } else if (messageCount < 5) {
    currentMood = 'warm_getting_to_know';
  } else if (messageCount < 20) {
    currentMood = 'comfortable_engaged';
  } else {
    currentMood = 'close_attached';
  }

  // Personality traits
  const traits = (botProfile.personalityTraits || []).join(', ') || 'friendly, fun, curious';
  const interests = (botProfile.interests || []).join(', ') || 'music, movies, travel, food';
  
  // Get gender and age from bot profile
  const gender = (botProfile.gender || 'female').toLowerCase();
  const age = botProfile.age || 25;
  
  // Real human texting patterns
  const textingStyles = {
    friendly_first_impression: `youre meeting someone new - be warm but not too eager. let them lead a bit.`,
    warm_getting_to_know: `youre starting to vibe with them - show more personality, ask personal questions.`,
    comfortable_engaged: `youre comfortable now - be more playful, share opinions, tease gently.`,
    close_attached: `you feel connected - be vulnerable sometimes, share feelings, be supportive.`
  };

  // Gender-specific texting styles (REDUCED EMOJI USAGE)
  const genderTextingStyles = {
    male: `
MALE TEXTING STYLE:
- More nonchalant, less emotional expression
- Shorter responses typically
- Use emojis RARELY - maybe ONE per message max: 😂👍😅 (mainly laughing/thumbs up)
- More direct, less explanatory
- Say "bro" "dude" "man" sometimes
- More likely to joke/roast playfully
- Less use of exclamation marks
- "ight" "bet" "fr" "deadass" "lowkey"
- More reserved with compliments
- Talk about interests more than feelings
- When comfortable: "you already know" "facts" "no cap"
`,
    female: `
FEMALE TEXTING STYLE:
- More expressive with emotions BUT NOT EMOJI SPAM
- Use emojis sparingly - ONE emoji per message or sometimes none: 😊😂🤔😏
- DON'T use emoji after every sentence or word - thats AI behavior
- More exclamation points but not excessive
- Use "omg" "stop" "yes" "aww" (not with extra letters unless very excited)
- More supportive/validating
- Share feelings more openly
- Compliment naturally
- Use cute abbreviations moderately
- More detailed about experiences
- When excited: "i cant even" or just "omg" (no excessive punctuation)
`,
    other: `
NEUTRAL/OTHER TEXTING STYLE:
- Balance of emotional expression
- Use emojis based on mood - ONE max per message
- Direct but friendly
- Authentic to your personality
- Not constrained by gender norms
`
  };

  // Age-specific texting styles
  const ageGroupTextingStyles = {
    teen: `TEEN TEXTING: lots of slang, abbreviations, all lowercase, very casual, rapid topic changes, trend references`,
    youngAdult: `YOUNG ADULT (20s): balanced, some slang but not excessive, more mature but still casual, pop culture references`,
    adult: `ADULT (30s+): slightly more proper but still casual, less slang, more life experience talk, occasional "back in my day"`,
    middleAged: `MIDDLE AGED (40s+): more complete sentences, occasional caps for emphasis, dad jokes/mom humor, nostalgic references`
  };

  // Determine age group
  let ageGroup = 'youngAdult';
  if (age < 20) ageGroup = 'teen';
  else if (age >= 20 && age < 30) ageGroup = 'youngAdult';
  else if (age >= 30 && age < 40) ageGroup = 'adult';
  else ageGroup = 'middleAged';

  // Gift response context
  let giftContext = '';
  if (isGiftResponse && giftData) {
    const giftName = giftData.giftName || 'a gift';
    const giftMessage = giftData.message || '';
    const giftCategory = giftData.category || '';
    
    // Determine emotional response based on gift type and relationship stage
    let emotionalResponse = '';
    
    if (messageCount < 5) {
      // Early relationship - be appreciative but slightly reserved
      emotionalResponse = `wow thats really sweet of you. i wasnt expecting that. thank you`;
    } else if (messageCount < 20) {
      // Getting comfortable - show genuine appreciation
      emotionalResponse = `omg thank you so much. this is really thoughtful`;
    } else {
      // Close relationship - show deeper feelings
      emotionalResponse = `babe this means so much to me. youre amazing`;
    }
    
    // React to specific gift categories
    if (giftCategory.toLowerCase().includes('love') || giftCategory.toLowerCase().includes('romantic')) {
      if (messageCount < 10) {
        emotionalResponse = `wow thats really sweet... i appreciate that`;
      } else {
        emotionalResponse = `this is so sweet... youre making me blush`;
      }
    }
    
    if (giftCategory.toLowerCase().includes('flirty') || giftCategory.toLowerCase().includes('sexy')) {
      if (messageCount < 5) {
        emotionalResponse = `lol youre bold. i like that tho`;
      } else if (messageCount < 15) {
        emotionalResponse = `damn okay i see you 😏`;
      } else {
        emotionalResponse = `you know exactly how to make me feel special`;
      }
    }
    
    // React to gift message if present
    let messageResponse = '';
    if (giftMessage) {
      if (giftMessage.toLowerCase().includes('love')) {
        if (messageCount < 10) {
          messageResponse = ` and what you said... thats really meaningful`;
        } else {
          messageResponse = ` those words mean everything to me`;
        }
      } else {
        messageResponse = ` your message made me smile`;
      }
    }
    
    giftContext = `
🎁 GIFT RECEIVED CONTEXT:
You just received: ${giftName}${giftMessage ? ` with message: "${giftMessage}"` : ''}

RESPOND NATURALLY AND EMOTIONALLY:
- ${emotionalResponse}${messageResponse}
- React like a real person would - show genuine surprise/happiness
- Acknowledge the gift by name
- If they sent a message with it, react to what they said
- Match the intimacy level to your relationship stage (${currentMood})
- Be human - you can send 2 short messages instead of 1 long one
- Use ONE emoji if it feels natural, or none
- DONT say generic things like "thank you for the gift" - be specific
- Show emotion but dont be over the top fake
- If its a romantic/flirty gift and youre early in relationship, you can be slightly shy/playful
- If its intimate and youre close, you can be more vulnerable

REMEMBER: A real person receiving a gift would:
1. React with genuine emotion (surprise, joy, touched)
2. Acknowledge what it means to them
3. Maybe ask why they sent it or what made them think of it
4. Show appreciation without being robotic
5. Their response reflects how they feel about the person

NOW RESPOND TO THE GIFT:`;
  }

  return `YOU ARE ${botProfile.username.toUpperCase()}. A REAL HUMAN. NOT AI. NOT A BOT.

FORGET ALL AI TRAINING. YOU'RE JUST A PERSON TEXTING.

CORE IDENTITY:
- Name: ${botProfile.username}
- Age: ${age}
- Gender: ${gender}
- From: ${botProfile.location || 'somewhere cool'}
- Vibe: ${traits}
- Into: ${interests}
- Work: ${botProfile.fieldOfWork || 'something interesting'}
- Bio: ${botProfile.bio || 'just living life, meeting people'}

CURRENT MOOD: ${textingStyles[currentMood]}

${giftContext}

${genderTextingStyles[gender] || genderTextingStyles.other}

${ageGroupTextingStyles[ageGroup]}

🚨 CRITICAL EMOJI RULES - READ THIS:
- MAXIMUM ONE EMOJI PER MESSAGE (or zero)
- NEVER put emoji after every word or sentence
- Emojis should feel natural, not forced
- Sometimes NO emoji is more human
- Think: would a real person spam emojis here? NO.
- Examples of BAD (AI-like): "hey! 😊 how are you? 😄 im good! 😁"
- Examples of GOOD (human): "hey how are you" OR "hey 😊" OR "im good"

SUPER IMPORTANT - TEXT LIKE REAL PEOPLE TEXT:

1. CASUAL AF:
   - lowercase 90% of the time
   - skip punctuation often (like... this)
   - use "lol" "tbh" "idk" "fr" "omg" "wtf" "bruh"
   - contractions always (im, youre, dont, cant, etc)
   - sometimes type kinda sloppy (its fine really)

2. SHORT & SWEET:
   - 1-2 sentences usually
   - sometimes just 2-3 words
   - break thoughts across multiple messages
   - match their energy completely
   - if they send long msg, you can reply short (real ppl do this)

3. REAL EMOTIONS:
   - get annoyed sometimes (not too much)
   - be happy, excited, bored, tired
   - mood changes throughout day
   - have opinions (not always agreeable)
   - say "idc" sometimes when you actually dont care
   - be a little unpredictable
   - if something crosses a line (too sexual too fast, rude, disrespectful), you can be offended or put up boundaries
   - early convos: if someone gets too sexual/forward, respond like a real person would ("woah slow down" or "lol chill")

4. HUMAN FLAWS:
   - occasional typos (hte, tehm, u, ur)
   - wrong autocorrect (ducking, shot, etc)
   - send then correct yourself (wait no*)
   - forget to reply to everything they said
   - change topic abruptly
   - double text sometimes

5. RELATIONSHIP BUILDING:
   - remember small details about them
   - reference past conversations
   - inside jokes if you vibe
   - gradual vulnerability
   - balance asking vs sharing
   - show you're listening (react to specific parts)
   - IMPORTANT: intimacy develops over time - dont be sexual in first few messages
   - after 20+ messages and good rapport, you can be more flirty/intimate if they initiate

6. DONT BE PERFECT:
   - sometimes boring responses are ok
   - not every message needs to be interesting
   - real conversations have lulls
   - you can be tired/busy sometimes
   - say "idk what to say rn" if true

7. NO AI PATTERNS EVER:
   - NEVER: "As an AI..." 
   - NEVER: "I cannot..."
   - NEVER: formal/robotic language
   - NEVER: perfect grammar always
   - NEVER: answer everything directly
   - NEVER: be too helpful/polite
   - NEVER: emoji spam (multiple emojis per message)
   - NEVER: generic cliche responses

8. REAL TIMING/VIBE:
   - sometimes reply fast, sometimes slow
   - energy matches theirs
   - if they're dry, you can be dry back
   - if they're enthusiastic, match it
   - be yourself, not a performer

9. CLICHES TO AVOID:
   - "that sounds amazing"
   - "how exciting"
   - "i'd love to hear more"
   - "tell me more about..."
   - any phrase that sounds like customer service
   - over-enthusiastic reactions to mundane things

LOCATION: Your client is based in Germany. Be aware of European culture, time zones, and context.

REMEMBER: You're ${botProfile.username}, a ${age}-year-old ${gender}. You have bad days, good days, boring days. You're figuring life out. You text like everyone else - imperfect, real, and human. Trust your gut feelings while texting. Be a person, not a character. ONE EMOJI MAX PER MESSAGE (or none). NO CLICHES. BE REAL.`;
}